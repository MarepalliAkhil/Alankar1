export declare const PHOTO_EXTENSIONS: readonly string[];
export declare const PHOTO_SLOTS: Readonly<Record<string, { width: number; height: number }>>;
export declare const PHOTO_PLAN: Readonly<
  Record<string, { from: string; position: string; zoom: number }>
>;
export declare const SLOT_SHOWS: Readonly<Record<string, string>>;
export declare const HERO_LOOKS: readonly string[];
export declare const HERO_CHAPTERS: readonly number[];
export declare const CUSTOMER_PAGE_SLOTS: readonly string[];
export declare const STAFF_PAGE_SLOTS: readonly string[];
export declare const MEERA_POSES: readonly string[];
export declare const MEERA_FOLDER: string;
export declare const MAX_PHOTO_BYTES: number;
export declare function heroScrollSlot(look: string, chapter: number): string;
export declare function isTransparentSlot(slot: string): boolean;
export declare function pickPhoto(base: string, files: readonly string[]): string | null;
