import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArtImage } from '../ui/ArtImage';
import { Button } from '../ui/Button';
import { Footsteps } from './Footsteps';
import { Meera } from './Meera';
import { speak } from './tours';
import type { TourDefinition } from './types';

export interface TourProps {
  definition: TourDefinition;
  /** The person's first name, used in Meera's lines. */
  name: string;
  /** Phones show the menu in a drawer and the tour as a bottom sheet. */
  isPhone: boolean;
  openMenu: (open: boolean) => void;
  /** Reached the end (Close or the finale's button): stored as completed. */
  onFinish: () => void;
  /** "Skip": leave the tour; stored as skipped. */
  onSkip: () => void;
  /** "Not now": close it for now; stored as dismissed. Both can be restarted from the menu. */
  onNotNow: () => void;
  /** The finale's button (for example "Book your first visit"). */
  onAction: (to: string) => void;
}

interface Box {
  top: number;
  left: number;
  width: number;
  height: number;
}

/** Every matching element that is actually on screen (the menu exists twice on phones). */
// eslint-disable-next-line react-refresh/only-export-components
export function findTarget(name: string): HTMLElement | null {
  const nodes = document.querySelectorAll<HTMLElement>(`[data-tour="${name}"]`);
  for (const node of nodes) {
    const r = node.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) return node;
  }
  return null;
}

function union(elements: HTMLElement[]): Box {
  const rects = elements.map((el) => el.getBoundingClientRect());
  const top = Math.min(...rects.map((r) => r.top));
  const left = Math.min(...rects.map((r) => r.left));
  const bottom = Math.max(...rects.map((r) => r.bottom));
  const right = Math.max(...rects.map((r) => r.right));
  return { top, left, width: right - left, height: bottom - top };
}

/**
 * The customer tour: Meera, the guide, tells a short story in chapters. Each chapter has her pose,
 * a small photo panel, Meera's picture, a speech bubble and a spotlight on the real control. Progress is a
 * footsteps path. On desktop the card docks at the bottom-left of the page content; on phones it
 * is a bottom sheet. Back, Next, Skip and Not now are always there. Keyboard: Tab stays in the
 * card and Escape closes it; a screen reader hears each chapter in a polite live region.
 * A chapter whose controls are not on screen is skipped.
 */
export function Tour({
  definition,
  name,
  isPhone,
  openMenu,
  onFinish,
  onSkip,
  onNotNow,
  onAction,
}: TourProps) {
  const { steps, finale } = definition;
  const [index, setIndex] = useState(0);
  const [done, setDone] = useState(false);
  const [box, setBox] = useState<Box | null>(null);
  const direction = useRef<1 | -1>(1);
  const cardRef = useRef<HTMLDivElement>(null);
  const spotRef = useRef<HTMLDivElement>(null);
  const primaryRef = useRef<HTMLButtonElement>(null);
  const titleId = useId();
  const textId = useId();
  const step = done ? undefined : steps[index];
  const last = index === steps.length - 1;
  const doneRef = useRef(done);
  const closeRef = useRef({ onFinish, onNotNow });
  useEffect(() => {
    doneRef.current = done;
    closeRef.current = { onFinish, onNotNow };
  });
  const openMenuRef = useRef(openMenu);
  useEffect(() => {
    openMenuRef.current = openMenu;
  });

  const finishOrFinale = useCallback(() => {
    if (finale) {
      setDone(true);
      setBox(null);
    } else onFinish();
  }, [finale, onFinish]);

  const go = useCallback(
    (delta: 1 | -1) => {
      direction.current = delta;
      if (done) {
        if (delta === -1) {
          setDone(false);
          setIndex(steps.length - 1);
        }
        return;
      }
      const next = index + delta;
      if (next >= steps.length) finishOrFinale();
      else if (next >= 0) setIndex(next);
    },
    [done, index, steps.length, finishOrFinale],
  );

  // Find the real controls for this chapter (opening the phone menu first), or skip the chapter.
  useEffect(() => {
    if (!step) {
      if (isPhone) openMenuRef.current(false);
      return;
    }
    if (isPhone) openMenuRef.current(Boolean(step.menu));
    let tries = 0;
    let timer = 0;
    let elements: HTMLElement[] = [];
    const measure = () => {
      if (elements.length > 0) setBox(union(elements));
    };
    const look = () => {
      elements = step.targets.map((t) => findTarget(t)).filter((el): el is HTMLElement => !!el);
      if (elements.length > 0) {
        elements[0]?.scrollIntoView?.({ block: 'center' });
        measure();
        // The phone drawer pulls focus into itself when it opens: bring it back to the card.
        window.requestAnimationFrame(() => primaryRef.current?.focus());
        return;
      }
      tries += 1;
      if (tries > 12) {
        // Not there: skip this chapter in the direction we were travelling.
        setBox(null);
        if (direction.current === 1) {
          if (last) finishOrFinale();
          else setIndex(index + 1);
        } else if (index > 0) setIndex(index - 1);
        else setIndex(index + 1);
        return;
      }
      timer = window.setTimeout(look, 40);
    };
    setBox(null);
    look();
    window.addEventListener('resize', measure);
    window.addEventListener('scroll', measure, true);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('resize', measure);
      window.removeEventListener('scroll', measure, true);
    };
    // The chapter index identifies the step; the rest are stable or read through refs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, isPhone, done]);

  // Focus follows the chapter; Tab is kept in the card; Escape closes it. A native listener on
  // the card stops the phone drawer's own Tab/Escape handling from taking over.
  useEffect(() => {
    primaryRef.current?.focus();
  }, [index, done]);
  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const close = () =>
      doneRef.current ? closeRef.current.onFinish() : closeRef.current.onNotNow();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        close();
        return;
      }
      if (event.key !== 'Tab') return;
      event.stopPropagation();
      const items = Array.from(card.querySelectorAll<HTMLElement>('button:not([disabled])'));
      if (items.length === 0) return;
      const first = items[0]!;
      const lastItem = items[items.length - 1]!;
      if (!card.contains(document.activeElement)) {
        event.preventDefault();
        first.focus();
      } else if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        lastItem.focus();
      } else if (!event.shiftKey && document.activeElement === lastItem) {
        event.preventDefault();
        first.focus();
      }
    };
    card.addEventListener('keydown', onKey);
    const onDocKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !card.contains(event.target as Node)) close();
    };
    document.addEventListener('keydown', onDocKey, true);
    return () => {
      card.removeEventListener('keydown', onKey);
      document.removeEventListener('keydown', onDocKey, true);
      previous?.focus?.();
    };
  }, []);

  // Geometry is measured at run time, so it is written to the elements directly (not inline JSX
  // styles, which the design rules forbid). The card docks next to the sidebar, never over it.
  useLayoutEffect(() => {
    const spot = spotRef.current;
    if (spot && box) {
      spot.style.top = `${box.top - 4}px`;
      spot.style.left = `${box.left - 4}px`;
      spot.style.width = `${box.width + 8}px`;
      spot.style.height = `${box.height + 8}px`;
    }
    const card = cardRef.current;
    if (card && !isPhone) {
      const side = document.querySelector('aside')?.getBoundingClientRect();
      const edge = side && side.width > 0 && side.right < window.innerWidth / 2 ? side.right : 0;
      card.style.left = `${edge + 16}px`;
    } else if (card) {
      card.style.left = '';
    }
  });

  const shown = done ? finale : step;
  if (!shown) return null;
  const speech = speak(shown.speech, name);
  const heading = shown.title;
  const countText = done ? 'Finished' : `Chapter ${index + 1} of ${steps.length}`;

  return createPortal(
    <div data-tour-root>
      <div aria-hidden="true" className="fixed inset-0 z-toast" />
      {box ? (
        <div
          ref={spotRef}
          aria-hidden="true"
          className="tour-spot pointer-events-none fixed z-toast rounded-nested"
        />
      ) : (
        <div aria-hidden="true" className="tour-dim fixed inset-0 z-toast" />
      )}
      <div
        ref={cardRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={textId}
        data-tour-card
        data-chapter={done ? 'finale' : index + 1}
        className="tour-card fixed bottom-0 z-toast flex w-full flex-col gap-sm rounded-t-card glass-photo p-md sm:bottom-md sm:w-[26rem] sm:rounded-card sm:p-lg"
      >
        <div className="flex items-start justify-between gap-sm">
          <p className="tabular text-xs font-semibold text-text-muted">{countText}</p>
          <Footsteps count={steps.length} current={done ? steps.length : index} />
        </div>
        <div className="hidden h-20 overflow-hidden rounded-nested border border-border sm:block">
          <ArtImage slot={shown.panel} className="h-full w-full" />
        </div>
        <div className="flex items-end gap-sm">
          <Meera
            pose={shown.pose}

            className="h-36 w-28 shrink-0 sm:h-44 sm:w-36"
          />
          <div className="relative min-w-0 flex-1 rounded-card rounded-bl-none border border-border bg-primary-soft p-sm">
            <h2 id={titleId} className="text-sm font-semibold text-text">
              {heading}
            </h2>
            <p id={textId} className="text-sm text-text">
              {speech}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-sm">
          <div className="flex gap-1">
            <Button variant="ghost" size="sm" onClick={done ? onFinish : onSkip}>
              Skip
            </Button>
            <Button variant="ghost" size="sm" onClick={done ? onFinish : onNotNow}>
              Not now
            </Button>
          </div>
          <div className="flex gap-sm">
            <Button
              variant="secondary"
              size="sm"
              disabled={index === 0 && !done}
              onClick={() => go(-1)}
            >
              Back
            </Button>
            {done && finale ? (
              <Button ref={primaryRef} size="sm" onClick={() => onAction(finale.action.to)}>
                {finale.action.label}
              </Button>
            ) : (
              <Button ref={primaryRef} size="sm" onClick={() => go(1)}>
                {last ? 'Finish' : 'Next'}
              </Button>
            )}
          </div>
        </div>
      </div>
      <p role="status" aria-live="polite" className="sr-only">
        {countText}: {heading}. {speech}
      </p>
    </div>,
    document.body,
  );
}
