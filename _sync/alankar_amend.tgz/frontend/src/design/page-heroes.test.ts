import { describe, expect, it } from 'vitest';
import { CHAPTERS, HOME_LOOKS, art, heroSlot } from './art';
import { ALL_MAPPED_SLOTS, pageHeroFor } from './page-heroes';

describe('page header images (17D)', () => {
  it('maps every page in the brief to its slot', () => {
    const cases: [string, Parameters<typeof pageHeroFor>[1], string][] = [
      ['/customer/book', 'customer', 'book-hero'],
      ['/customer/appointments', 'customer', 'bookings-hero'],
      ['/customer/chat', 'customer', 'chat-hero'],
      ['/customer/wallet', 'customer', 'wallet-hero'],
      ['/customer/packages', 'customer', 'packages-hero'],
      ['/gift-cards', 'admin', 'giftcards-hero'],
      ['/customer/shop', 'customer', 'shop-hero'],
      ['/customer/orders', 'customer', 'orders-hero'],
      ['/customer-dashboard', 'customer', 'customer-dashboard-hero'],
      ['/requests', 'stylist', 'stylist-requests-hero'],
      ['/my-schedule', 'stylist', 'stylist-schedule-hero'],
      ['/appointments', 'receptionist', 'receptionist-board-hero'],
      ['/dashboard', 'admin', 'admin-stats-hero'],
      ['/payroll', 'admin', 'payroll-hero'],
      ['/inventory', 'admin', 'inventory-hero'],
      ['/zenotians', null, 'zenotians-hero'],
      ['/zenotians/about/skills', 'customer', 'zenotians-hero'],
      ['/login', null, 'login-hero'],
      ['/register', null, 'register-hero'],
    ];
    for (const [path, role, slot] of cases) {
      expect(pageHeroFor(path, role)?.slot, path).toBe(slot);
    }
  });

  it('shows only the brand image on the profile pages', () => {
    expect(pageHeroFor('/customer/profile', 'customer')).toEqual({
      slot: 'brand-image',
      strip: false,
    });
    expect(pageHeroFor('/profile', 'stylist')).toEqual({ slot: 'brand-image', strip: true });
  });

  it('gives staff screens the slim strip and others the banner', () => {
    expect(pageHeroFor('/payroll', 'admin')?.strip).toBe(true);
    expect(pageHeroFor('/customer/book', 'customer')?.strip).toBe(false);
  });

  it('has no header image for pages that are not listed', () => {
    expect(pageHeroFor('/', null)).toBeNull();
    expect(pageHeroFor('/customer/pay/12', 'customer')).toBeNull();
    expect(pageHeroFor('/customers', 'admin')).toBeNull();
  });

  it('registers every mapped slot as a decorative photo slot', () => {
    for (const slot of ALL_MAPPED_SLOTS) {
      const entry = art[slot];
      expect(entry, slot).toBeTruthy();
      expect(entry.decorative && entry.alt === '', slot).toBe(true);
    }
  });
});

describe('home background slots (17C)', () => {
  it('has six chapters for the neutral look and each division look', () => {
    const names = HOME_LOOKS.flatMap((look) => CHAPTERS.map((n) => heroSlot(look, n)));
    expect(names).toHaveLength(24);
    expect(names).toContain('hero-scroll-01');
    expect(names).toContain('spa-hero-scroll-06');
    for (const name of names) {
      expect(art[name].width, name).toBe(1920);
      expect(art[name].height, name).toBe(1080);
    }
  });
});
