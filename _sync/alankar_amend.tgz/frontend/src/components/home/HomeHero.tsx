import { ArrowDown, MapPin, Phone } from 'lucide-react';
import type { SiteData } from '../../api/public';
import { brand } from '../../config/brand';
import { AlankarIcon, ArtImage, ButtonLink } from '../ui';
import { PageContainer } from '../layout/PageContainer';

export interface HomeHeroProps {
  site: SiteData | undefined;
  loading: boolean;
  /** Where "Book a visit" goes (the sign-in step for guests). */
  book: string;
  /** Staff who open the public site get a way back to their own screens instead of booking. */
  staffHome: string | null;
  tel: string | undefined;
}

/**
 * The first screen. It has to say in five seconds what this is: a salon, a spa and a beauty parlor
 * with online booking. Words lead on the left, one real photo in an arch on the right, and the
 * shop's real hours, address and phone sit right under the buttons (all from the shop settings).
 */
export function HomeHero({ site, loading, book, staffHome, tel }: HomeHeroProps) {
  const hours = (site?.hours ?? []).slice(0, 2);
  const contact = site?.contact;
  return (
    <section
      data-hero="home"
      data-home-chapter="1"
      aria-labelledby="home-title"
      className="relative overflow-hidden"
    >
      <div
        aria-hidden="true"
        className="ornament absolute -right-24 -top-24 h-[34rem] w-[34rem] shape-leaf"
      />
      <PageContainer className="relative grid items-center gap-xl pb-xl pt-lg lg:grid-cols-12 lg:gap-2xl lg:py-2xl">
        <div className="glass-photo flex flex-col gap-lg rounded-card p-lg lg:col-span-7 lg:p-xl">
          <p className="inline-flex w-fit items-center gap-sm rounded-full border border-border bg-surface px-md py-1 text-sm font-medium text-primary-hover">
            <AlankarIcon name="scissors" className="h-4 w-4" />
            <span>{brand.shopTagline}</span>
          </p>
          <h1 id="home-title" className="text-6xl">
            Hair, skin and a quiet hour.{' '}
            <span className="block text-primary-hover">Book it online.</span>
          </h1>
          <p className="max-w-[52ch] text-lg text-text-muted">
            {brand.shopName} is a salon, a spa and a beauty parlor under one roof. Pick a service,
            your stylist confirms the time, and you pay on a secure link. Then you just walk in.
          </p>
          <div className="flex flex-wrap items-center gap-sm">
            {staffHome ? (
              <ButtonLink to={staffHome} size="lg">
                Go to your dashboard
              </ButtonLink>
            ) : (
              <ButtonLink to={book} size="lg">
                Book a visit
              </ButtonLink>
            )}
            <a
              href="#divisions"
              className="inline-flex h-12 items-center gap-2 rounded-full px-6 text-base font-semibold text-primary-hover hover:bg-primary-soft focus-visible:shadow-focus focus-visible:outline-none"
            >
              See what we do <ArrowDown aria-hidden="true" className="h-4 w-4" />
            </a>
          </div>
          <ul
            aria-label="Visit details"
            className="flex flex-col gap-sm border-t border-border pt-md text-sm text-text-muted sm:flex-row sm:flex-wrap sm:gap-lg"
          >
            {loading && !site && <li>Loading hours and address…</li>}
            {hours.map((row) => (
              <li key={row.days} className="flex items-center gap-sm">
                <AlankarIcon name="door" className="h-4 w-4 text-primary-hover" />
                <span className="tabular">
                  {row.closed ? `${row.days}: closed` : `${row.days}: ${row.open} to ${row.close}`}
                </span>
              </li>
            ))}
            {contact?.address && (
              <li className="flex items-center gap-sm">
                <MapPin aria-hidden="true" className="h-4 w-4 text-primary-hover" />
                {contact.address}
              </li>
            )}
            {contact?.phone && tel && (
              <li>
                <a
                  href={`tel:${tel}`}
                  className="flex items-center gap-sm font-medium text-primary-hover underline-offset-4 hover:underline"
                >
                  <Phone aria-hidden="true" className="h-4 w-4" />
                  {contact.phone}
                </a>
              </li>
            )}
          </ul>
        </div>
        <div className="relative mx-auto w-full max-w-md lg:col-span-5 lg:max-w-none">
          <div className="shape-arch relative aspect-[4/5] overflow-hidden border border-border bg-surface-muted shadow-raised">
            <ArtImage slot="shopBackground" priority className="absolute inset-0 h-full w-full" />
          </div>
          <p className="absolute -bottom-4 left-md right-md flex items-center gap-sm rounded-nested border border-border bg-surface px-md py-sm text-sm text-text shadow-card sm:left-auto sm:right-lg sm:max-w-xs">
            <AlankarIcon name="approve" className="h-5 w-5 shrink-0 text-primary-hover" />
            Your stylist and the front desk both say yes before anything is final.
          </p>
        </div>
      </PageContainer>
    </section>
  );
}
