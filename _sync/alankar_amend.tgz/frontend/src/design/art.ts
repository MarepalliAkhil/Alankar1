/**
 * Every picture slot in the app, in one place: the owner's real photos only.
 *
 * Seven photos exist (the base slots below). Every other slot (the 24 home scroll chapters, the 18
 * page headers and the Alankar brand image) is ASSIGNED one of them with its own crop and zoom
 * (vite-plugins/photo-slots.js, PHOTO_PLAN), so neighbouring chapters and pages look different.
 * A photo with the slot's own name in frontend/public/photos/ always wins over the assignment, and
 * an image the admin sets in the content editor wins over both. A slot with no photo at all shows a
 * plain themed gradient: there is no drawn artwork anywhere. See docs/IMAGE_SLOTS.md.
 */
import {
  CUSTOMER_PAGE_SLOTS,
  HERO_CHAPTERS,
  HERO_LOOKS,
  PHOTO_PLAN,
  PHOTO_SLOTS,
  SLOT_SHOWS,
  STAFF_PAGE_SLOTS,
  heroScrollSlot,
  pickPhoto,
} from '../../vite-plugins/photo-slots.js';

export type HeroLook = 'neutral' | 'salon' | 'spa' | 'parlor';
export type Chapter = 1 | 2 | 3 | 4 | 5 | 6;
export const CHAPTERS: readonly Chapter[] = [1, 2, 3, 4, 5, 6];
export type HeroSlot =
  `hero-scroll-0${Chapter}` | `${Exclude<HeroLook, 'neutral'>}-hero-scroll-0${Chapter}`;
export type PageSlot =
  | 'book-hero'
  | 'bookings-hero'
  | 'chat-hero'
  | 'wallet-hero'
  | 'packages-hero'
  | 'shop-hero'
  | 'orders-hero'
  | 'customer-dashboard-hero'
  | 'zenotians-hero'
  | 'login-hero'
  | 'register-hero'
  | 'giftcards-hero'
  | 'stylist-requests-hero'
  | 'stylist-schedule-hero'
  | 'receptionist-board-hero'
  | 'admin-stats-hero'
  | 'payroll-hero'
  | 'inventory-hero';
export type SceneSlot = HeroSlot | PageSlot | 'brand-image';

export const heroSlot = (look: HeroLook, chapter: Chapter): HeroSlot =>
  heroScrollSlot(look, chapter) as HeroSlot;
export const STAFF_SLOTS: readonly string[] = STAFF_PAGE_SLOTS;
export const CUSTOMER_SLOTS: readonly string[] = CUSTOMER_PAGE_SLOTS;
export const HOME_LOOKS: readonly HeroLook[] = HERO_LOOKS as readonly HeroLook[];

export interface ArtSlot {
  /** What the picture shows (for the docs and the design-system page). */
  description: string;
  /** Decorative pictures are hidden from screen readers; meaningful ones have `alt`. */
  decorative: boolean;
  alt: string;
  /** The slot's own photo: public/photos/<photo>.(webp|jpg|jpeg|png). */
  photo: string;
  /** Recommended photo size in pixels. */
  width: number;
  height: number;
}

const base = (photo: string, description: string): ArtSlot => ({
  description,
  decorative: true,
  alt: '',
  photo,
  ...PHOTO_SLOTS[photo],
});

const baseSlots = {
  salonBackground: base(
    'salon-background',
    'Salon background: a night styling studio with a gold-lit round mirror, a leather barber chair and a dark navy wall.',
  ),
  spaBackground: base(
    'spa-background',
    'Spa background: stacked stones and a lotus on a grey dish, olive-green wall, soft light.',
  ),
  parlorBackground: base(
    'parlor-background',
    'Beauty Parlor background: rose petals, blush powder and a makeup brush on pink marble.',
  ),
  salonHero: base(
    'salon-hero',
    'Home hero, Salon stage: a barber studio with two chairs and tall gold-lit arched mirrors.',
  ),
  spaHero: base(
    'spa-hero',
    'Home hero, Spa stage: a massage bed with towels, candles and stones in a sage-green room.',
  ),
  parlorHero: base(
    'parlor-hero',
    'Home hero, Beauty Parlor stage: a blush-pink vanity with a round bulb-lit mirror and flowers.',
  ),
  shopBackground: base(
    'shop-background',
    'Shop background (staff portals and brand pages): the Alankar reception and styling floor with the shop sign, bright and airy.',
  ),
};

const sceneSlots: Record<string, ArtSlot> = {};
for (const slot of Object.keys(PHOTO_PLAN)) {
  sceneSlots[slot] = {
    description: SLOT_SHOWS[slot],
    decorative: true,
    alt: '',
    photo: slot,
    ...PHOTO_SLOTS[slot],
  };
}

export const art = { ...baseSlots, ...sceneSlots } as typeof baseSlots & Record<SceneSlot, ArtSlot>;
export type ArtId = keyof typeof art;

/** Every slot name that has a photo-slot entry. */
export const HERO_SLOT_NAMES: readonly string[] = HERO_LOOKS.flatMap((look) =>
  HERO_CHAPTERS.map((n) => heroScrollSlot(look, n)),
);

export interface Crop {
  /** CSS object-position, e.g. "70% 40%". */
  position: string;
  /** 1 = the whole photo; larger = a closer crop. */
  zoom: number;
}
export interface Sources {
  src: string;
  webp: string | null;
}
export interface Resolved extends Sources {
  /** The slot's own photo, or one of the seven assigned to it. */
  kind: 'own' | 'assigned';
  /** The photo slot whose file is used (the slot itself, or the assigned base slot). */
  from: string;
  crop: Crop;
}

const CENTRE: Crop = { position: '50% 50%', zoom: 1 };

/**
 * The owner's photo for a slot, if one is in public/photos: `<photo>.webp`, then `.jpg`, `.jpeg`,
 * `.png` (any letter case). Null means the slot has no photo of its own.
 */
export function photoFor(slot: ArtSlot, available: readonly string[]): string | null {
  const match = pickPhoto(slot.photo, available);
  return match ? `/photos/${match}` : null;
}

/**
 * What the browser gets for a photo name: the chosen file, and when that is a WebP with a JPG
 * (or JPEG/PNG) next to it, the WebP as the preferred source and the other as the fallback <img>
 * for browsers without WebP. Null when there is no such photo.
 */
export function photoSources(
  slot: Pick<ArtSlot, 'photo'>,
  available: readonly string[],
): Sources | null {
  const chosen = pickPhoto(slot.photo, available);
  if (!chosen) return null;
  if (!/\.webp$/i.test(chosen)) return { src: `/photos/${chosen}`, webp: null };
  const fallback = pickPhoto(
    slot.photo,
    available.filter((name) => !/\.webp$/i.test(name)),
  );
  return fallback
    ? { src: `/photos/${fallback}`, webp: `/photos/${chosen}` }
    : { src: `/photos/${chosen}`, webp: null };
}

/**
 * The picture for a slot, in order: its own photo (centred, as supplied), else the photo assigned
 * to it with the planned crop, else null (a plain themed gradient is shown).
 */
export function resolveSlot(slot: ArtSlot, available: readonly string[]): Resolved | null {
  const own = photoSources(slot, available);
  if (own) return { ...own, kind: 'own', from: slot.photo, crop: CENTRE };
  const plan = (PHOTO_PLAN as Record<string, { from: string; position: string; zoom: number }>)[
    slot.photo
  ];
  if (!plan) return null;
  const assigned = photoSources({ photo: plan.from }, available);
  if (!assigned) return null;
  return {
    ...assigned,
    kind: 'assigned',
    from: plan.from,
    crop: { position: plan.position, zoom: plan.zoom },
  };
}
