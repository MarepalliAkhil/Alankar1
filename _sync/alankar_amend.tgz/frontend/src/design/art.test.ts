import { describe, expect, it } from 'vitest';
import { PHOTO_PLAN, PHOTO_SLOTS } from '../../vite-plugins/photo-slots.js';
import { art, photoFor, resolveSlot } from './art';

const BASE = [
  'salon-hero',
  'spa-hero',
  'parlor-hero',
  'shop-background',
  'salon-background',
  'spa-background',
  'parlor-background',
];
const ALL_BASE_PHOTOS = BASE.flatMap((name) => [`${name}.webp`, `${name}.jpg`]);

describe('image slot registry', () => {
  it.each(Object.entries(art))('%s is described and sized', (_, slot) => {
    expect(slot.description.length).toBeGreaterThan(40);
    expect(slot.width).toBeGreaterThan(0);
    expect(slot.height).toBeGreaterThan(0);
    expect(slot.photo).toMatch(/^[a-z0-9-]+$/);
    if (!slot.decorative) expect(slot.alt.length).toBeGreaterThan(5);
  });

  it('uses a photo with the slot name when the owner adds one, in any allowed format', () => {
    expect(photoFor(art.spaBackground, [])).toBeNull();
    expect(photoFor(art.spaBackground, ['spa-background.webp'])).toBe(
      '/photos/spa-background.webp',
    );
    expect(photoFor(art.spaBackground, ['salon-background.jpg'])).toBeNull();
  });

  it('has no drawn artwork: no slot carries an SVG or illustration', () => {
    for (const slot of Object.values(art)) {
      expect(Object.keys(slot)).not.toContain('art');
      expect(Object.keys(slot)).not.toContain('files');
    }
  });
});

describe('assigned photos (no drawings, real photos reused with different crops)', () => {
  it('every assigned slot points at one of the seven real photos', () => {
    for (const [slot, plan] of Object.entries(PHOTO_PLAN)) {
      expect(BASE, slot).toContain(plan.from);
      expect(plan.position, slot).toMatch(/^\d{1,3}% \d{1,3}%$/);
      expect(plan.zoom, slot).toBeGreaterThanOrEqual(1);
      expect(PHOTO_SLOTS[slot], slot).toBeTruthy();
    }
  });

  it('every home chapter, page header and the brand image resolves to a photo', () => {
    for (const slot of Object.keys(PHOTO_PLAN)) {
      const entry = art[slot as keyof typeof art];
      const resolved = resolveSlot(entry, ALL_BASE_PHOTOS);
      expect(resolved, slot).not.toBeNull();
      expect(resolved?.kind).toBe('assigned');
    }
  });

  it('neighbouring home chapters never show the same crop of the same photo', () => {
    for (const look of ['', 'salon-', 'spa-', 'parlor-']) {
      for (let n = 1; n < 6; n += 1) {
        const a = PHOTO_PLAN[`${look}hero-scroll-0${n}`];
        const b = PHOTO_PLAN[`${look}hero-scroll-0${n + 1}`];
        expect(`${a.from}|${a.position}|${a.zoom}`, `${look} ${n}`).not.toBe(
          `${b.from}|${b.position}|${b.zoom}`,
        );
      }
    }
  });

  it('a slot whose own photo is added uses it instead, centred', () => {
    const own = resolveSlot(art['book-hero'], [...ALL_BASE_PHOTOS, 'book-hero.png']);
    expect(own?.kind).toBe('own');
    expect(own?.crop).toEqual({ position: '50% 50%', zoom: 1 });
  });

  it('with none of the photos present nothing resolves (a gradient is shown)', () => {
    expect(resolveSlot(art['book-hero'], [])).toBeNull();
    expect(resolveSlot(art.salonHero, [])).toBeNull();
  });
});
