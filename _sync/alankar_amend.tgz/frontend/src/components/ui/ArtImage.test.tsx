import { render } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { ThemeProvider } from '../../design/ThemeProvider';
import { ArtImage } from './ArtImage';

vi.mock('virtual:photo-manifest', () => ({
  default: [
    'spa-hero.png',
    'spa-hero.JPG',
    'spa-hero.webp',
    'salon-hero.jpeg',
    'salon-hero.png',
    'shop-background.webp',
    'shop-background.jpg',
    'book-hero.webp',
  ],
}));
vi.mock('virtual:photo-placeholders', () => ({
  default: {
    'spa-hero': 'data:image/webp;base64,AAAA',
    'shop-background': 'data:image/webp;base64,BBBB',
  },
}));

function frame(slot: string) {
  return document.querySelector<HTMLElement>(`[data-art-frame="${slot}"]`)!;
}

describe('ArtImage', () => {
  it('uses WebP with a JPG fallback, a blurred preview, cover fit and explicit size', () => {
    render(
      <ThemeProvider>
        <ArtImage slot="spaHero" priority overlay />
      </ThemeProvider>,
    );
    const f = frame('spaHero');
    expect(f).toHaveAttribute('data-source', 'photo');
    expect(f.querySelector('source')).toHaveAttribute('srcset', '/photos/spa-hero.webp');
    const img = f.querySelector('img')!;
    expect(img).toHaveAttribute('src', '/photos/spa-hero.JPG');
    expect(img).toHaveAttribute('width', '1920');
    expect(img).toHaveAttribute('height', '1080');
    expect(img).toHaveAttribute('loading', 'eager');
    expect(img).toHaveClass('object-cover');
    expect(f.style.getPropertyValue('--art-preview')).toBe('url("data:image/webp;base64,AAAA")');
    expect(f.style.getPropertyValue('--art-zoom')).toBe('1');
    expect(f.querySelector('.art-scrim')).not.toBeNull();
  });

  it('prefers jpeg over png and lazy-loads below the fold', () => {
    render(
      <ThemeProvider>
        <ArtImage slot="salonHero" />
      </ThemeProvider>,
    );
    const img = frame('salonHero').querySelector('img')!;
    expect(img).toHaveAttribute('src', '/photos/salon-hero.jpeg');
    expect(img).toHaveAttribute('loading', 'lazy');
    // No optimised preview for this photo: nothing is blurred behind it.
    expect(frame('salonHero').style.getPropertyValue('--art-preview')).toBe('');
  });

  it('a slot with no photo of its own shows the photo assigned to it, with its own crop', () => {
    render(
      <ThemeProvider>
        <ArtImage slot="hero-scroll-05" />
        <ArtImage slot="hero-scroll-06" />
        <ArtImage slot="login-hero" />
      </ThemeProvider>,
    );
    const five = frame('hero-scroll-05');
    const six = frame('hero-scroll-06');
    expect(five.querySelector('img')).toHaveAttribute('data-photo', 'shop-background');
    expect(five.querySelector('source')).toHaveAttribute('srcset', '/photos/shop-background.webp');
    // The same photo, cropped differently, so neighbouring chapters do not look the same.
    expect(six.querySelector('img')).toHaveAttribute('data-photo', 'shop-background');
    expect(five.style.getPropertyValue('--art-pos')).not.toBe(
      six.style.getPropertyValue('--art-pos'),
    );
    expect(Number(five.style.getPropertyValue('--art-zoom'))).toBeGreaterThan(1);
    // The blurred preview is the assigned photo's.
    expect(five.style.getPropertyValue('--art-preview')).toContain('BBBB');
    // Its photo (parlor-hero) is not in this manifest, so there is nothing to show but a gradient.
    expect(frame('login-hero')).toHaveAttribute('data-source', 'gradient');
  });

  it("a slot's own photo wins over the assigned one and is not cropped", () => {
    render(
      <ThemeProvider>
        <ArtImage slot="book-hero" />
      </ThemeProvider>,
    );
    const f = frame('book-hero');
    expect(f.querySelector('img')).toHaveAttribute('src', '/photos/book-hero.webp');
    expect(f.querySelector('img')).toHaveAttribute('data-photo', 'book-hero');
    expect(f.style.getPropertyValue('--art-zoom')).toBe('1');
  });

  it('with no photo anywhere it shows a plain gradient, never an image or a drawing', () => {
    render(
      <ThemeProvider>
        <ArtImage slot="parlorHero" />
      </ThemeProvider>,
    );
    const f = frame('parlorHero');
    expect(f).toHaveAttribute('data-source', 'gradient');
    expect(f.querySelector('img')).toBeNull();
    expect(f.querySelector('source')).toBeNull();
  });

  it('an image set by the admin wins over the photo', () => {
    render(
      <ThemeProvider>
        <ArtImage slot="spaHero" override="https://cdn.example.com/hero.jpg" />
      </ThemeProvider>,
    );
    const f = frame('spaHero');
    expect(f).toHaveAttribute('data-source', 'admin');
    expect(f.querySelector('img')).toHaveAttribute('src', 'https://cdn.example.com/hero.jpg');
    expect(f.querySelector('source')).toBeNull();
  });
});
