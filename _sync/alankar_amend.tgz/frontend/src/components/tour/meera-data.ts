/** The nine pictures of Meera, the guide. The owner supplies them as 3D character images. */
export const MEERA_POSES = [
  'wave',
  'point',
  'phone',
  'approve',
  'chat',
  'wallet',
  'stars',
  'shield',
  'celebrate',
] as const;
export type MeeraPose = (typeof MEERA_POSES)[number];

/** What a screen reader says about each pose (when Meera is not purely decoration). */
export const MEERA_ALT: Record<MeeraPose, string> = {
  wave: 'Meera, your stylist guide, waving',
  point: 'Meera, your stylist guide, pointing',
  phone: 'Meera, your stylist guide, holding a phone',
  approve: 'Meera, your stylist guide, giving a thumbs-up',
  chat: 'Meera, your stylist guide, chatting',
  wallet: 'Meera, your stylist guide, holding a wallet',
  stars: 'Meera, your stylist guide, holding five stars',
  shield: 'Meera, your stylist guide, holding a shield',
  celebrate: 'Meera, your stylist guide, celebrating',
};

/** The image slot for a pose: public/photos/meera/meera-<pose>.(webp|png|jpg|jpeg). */
export const meeraSlot = (pose: MeeraPose) => `meera-${pose}`;
