import { useEffect, useRef, useState } from 'react';
import { HOME_CHAPTERS } from '../../hooks/useHomeChapter';
import { heroSlot, type Chapter, type HeroLook } from '../../design/art';
import { cn } from '../../lib/cn';
import { ArtImage } from '../ui/ArtImage';

/**
 * Task 17C: ONE full-viewport background for the whole story at the top of the home page. It is
 * sticky inside its zone (so it scrolls away with the zone and never covers the rest of the page),
 * takes no space in the layout, and crossfades between the six chapter pictures as you scroll,
 * with a slow zoom (CSS only) and a theme tint that changes per chapter.
 *
 * Only the current and the next picture are mounted, so the browser loads at most two; the one
 * just left stays for the length of the fade. Each picture is a normal image slot (admin image,
 * then public/photos, then a plain themed gradient), decorative, with the blurred-preview loading of
 * ArtImage. With reduced motion there is no zoom and the fades are short.
 */
export function HomeBackdrop({
  chapter,
  look = 'neutral',
  firstImage,
}: {
  chapter: Chapter;
  look?: HeroLook;
  /** An image the admin set for the first chapter in the content editor. */
  firstImage?: string | null;
}) {
  const [leaving, setLeaving] = useState<Chapter | null>(null);
  const previous = useRef<Chapter>(chapter);
  useEffect(() => {
    if (previous.current === chapter) return;
    setLeaving(previous.current);
    previous.current = chapter;
    const timer = window.setTimeout(() => setLeaving(null), 1200);
    return () => window.clearTimeout(timer);
  }, [chapter]);

  const next = Math.min(6, chapter + 1) as Chapter;
  const mounted = HOME_CHAPTERS.filter((n) => n === chapter || n === next || n === leaving);
  return (
    <div
      aria-hidden="true"
      data-home-backdrop
      data-chapter={chapter}
      className="home-backdrop pointer-events-none sticky top-0 z-0 -mb-[100svh] h-[100svh] w-full overflow-hidden"
    >
      {mounted.map((n) => (
        <div
          key={n}
          data-home-layer={n}
          data-current={n === chapter}
          className={cn('home-layer absolute inset-0', n === chapter && 'is-current')}
        >
          <div className="home-zoom absolute inset-0">
            <ArtImage
              slot={heroSlot(look, n)}
              priority={n === 1}
              override={n === 1 ? firstImage : null}
              overlay
              className="absolute inset-0 h-full w-full"
            />
          </div>
        </div>
      ))}
      <span className="home-tint absolute inset-0" />
    </div>
  );
}
