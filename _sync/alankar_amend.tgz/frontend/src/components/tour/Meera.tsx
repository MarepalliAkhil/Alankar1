import { useEffect, useRef, useState } from 'react';
import photos from 'virtual:photo-manifest';
import { photoSources } from '../../design/art';
import { cn } from '../../lib/cn';
import { MEERA_ALT, meeraSlot, type MeeraPose } from './meera-data';

export interface MeeraProps {
  pose: MeeraPose;
  className?: string;
  /** Hidden from screen readers (her words are shown next to her). */
  decorative?: boolean;
}

/** A file type that can never have see-through parts. */
const isFlat = (src: string) => /\.jpe?g$/i.test(src);

/** True when the picture has a see-through corner (a cut-out), false when it has a plain background. */
function hasTransparentCorner(img: HTMLImageElement): boolean | null {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 8;
    canvas.height = 8;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(img, 0, 0, 8, 8);
    return ctx.getImageData(0, 0, 1, 1).data[3] < 250;
  } catch {
    return null;
  }
}

/**
 * Meera, the tour guide: the owner's 3D character picture for a pose, lazy-loaded at a fixed
 * size (no layout shift) with a gentle CSS-only float and shadow pulse. A cut-out (see-through
 * background) stands free; a picture with a plain background is shown as a rounded image with a
 * soft theme-tinted frame and faded edges. When the picture is missing (or fails to load) a glass
 * circle with the letter "M" shows instead, so the tour never waits for or breaks on an image.
 */
export function Meera({ pose, className, decorative = false }: MeeraProps) {
  const found = photoSources({ photo: meeraSlot(pose) }, photos);
  const src = found?.src ?? null;
  const [failed, setFailed] = useState<string | null>(null);
  const [cutout, setCutout] = useState<boolean | null>(null);
  const img = useRef<HTMLImageElement>(null);
  const usable = !!src && failed !== src;
  const flat = src ? isFlat(src) : false;
  const free = flat ? false : (cutout ?? true);

  useEffect(() => {
    setCutout(null);
  }, [src]);

  const check = () => {
    if (img.current && !flat) setCutout(hasTransparentCorner(img.current));
  };

  useEffect(() => {
    if (img.current?.complete && img.current.naturalWidth > 0) check();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src]);

  return (
    <div
      data-meera={pose}
      aria-hidden={decorative || undefined}
      data-meera-source={usable ? 'image' : 'letter'}
      className={cn('relative shrink-0', className)}
    >
      {usable ? (
        <>
          <span
            aria-hidden="true"
            className="meera-shadow absolute bottom-0 left-1/2 h-2 w-3/5 -translate-x-1/2 rounded-full bg-text/25 blur-sm"
          />
          <picture>
            {found?.webp && <source srcSet={found.webp} type="image/webp" />}
            <img
              ref={img}
              src={src!}
              alt={decorative ? '' : MEERA_ALT[pose]}
              aria-hidden={decorative || undefined}
              width={1024}
              height={1280}
              loading="lazy"
              decoding="async"
              onLoad={check}
              onError={() => setFailed(src)}
              className={cn(
                'meera-float relative h-full w-full object-contain',
                !free && 'meera-framed object-cover',
              )}
            />
          </picture>
        </>
      ) : (
        <div className="relative flex h-full w-full items-end justify-center">
          <span
            role={decorative ? undefined : 'img'}
            aria-label={decorative ? undefined : MEERA_ALT[pose]}
            aria-hidden={decorative || undefined}
            className="glass-photo flex aspect-square w-4/5 items-center justify-center rounded-full text-3xl font-semibold text-text"
          >
            M
          </span>
        </div>
      )}
    </div>
  );
}
