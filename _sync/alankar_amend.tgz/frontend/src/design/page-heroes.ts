/**
 * Task 17D: which header image each page shows. One static picture per page (the slot system is the same as
 * everywhere else: the slot's own photo, else the photo assigned to it, else a plain gradient; see
 * docs/IMAGE_SLOTS.md). The profile
 * page shows only the Alankar brand image. Pages that are not listed here get no header image.
 */
import type { Role } from '../policy/policy';
import { STAFF_SLOTS, type SceneSlot } from './art';

export interface PageHeroChoice {
  slot: SceneSlot;
  /** Staff screens get a slim strip (96 to 112 px); everything else a 4:1 banner. */
  strip: boolean;
}

/** Path -> slot for pages whose picture does not depend on who is signed in. */
const SHARED: Record<string, SceneSlot> = {
  '/login': 'login-hero',
  '/register': 'register-hero',
  '/customer-dashboard': 'customer-dashboard-hero',
  '/customer/book': 'book-hero',
  '/customer/appointments': 'bookings-hero',
  '/customer/waitlist': 'bookings-hero',
  '/customer/chat': 'chat-hero',
  '/customer/wallet': 'wallet-hero',
  '/customer/packages': 'packages-hero',
  '/customer/memberships': 'packages-hero',
  '/customer/shop': 'shop-hero',
  '/customer/orders': 'orders-hero',
  '/customer/invoices': 'orders-hero',
  '/requests': 'stylist-requests-hero',
  '/my-schedule': 'stylist-schedule-hero',
  '/payroll': 'payroll-hero',
  '/inventory': 'inventory-hero',
  '/gift-cards': 'giftcards-hero',
};

/** Pages whose picture depends on the role (the same path means a different screen). */
const BY_ROLE: Partial<Record<Role, Record<string, SceneSlot>>> = {
  admin: { '/dashboard': 'admin-stats-hero' },
  receptionist: { '/appointments': 'receptionist-board-hero' },
};

const PROFILE_PATHS = new Set(['/customer/profile', '/profile']);

export const ALL_MAPPED_SLOTS: readonly SceneSlot[] = [
  ...new Set([
    ...Object.values(SHARED),
    ...Object.values(BY_ROLE).flatMap((m) => Object.values(m ?? {})),
    'zenotians-hero' as const,
    'brand-image' as const,
  ]),
];

export function pageHeroFor(pathname: string, role: Role | null): PageHeroChoice | null {
  const path = pathname.length > 1 ? pathname.replace(/\/$/, '') : pathname;
  const staff = role !== null && role !== 'customer';
  if (PROFILE_PATHS.has(path)) return { slot: 'brand-image', strip: staff };
  if (path === '/zenotians' || path.startsWith('/zenotians/')) {
    return { slot: 'zenotians-hero', strip: false };
  }
  const slot = (role && BY_ROLE[role]?.[path]) || SHARED[path];
  if (!slot) return null;
  // Staff paths shared with customers do not exist, so the signed-in role decides the shape.
  return { slot, strip: STAFF_SLOTS.includes(slot) || staff };
}
