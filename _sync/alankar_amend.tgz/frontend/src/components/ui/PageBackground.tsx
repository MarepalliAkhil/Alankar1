import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import type { DivisionId } from '../../config/divisions';
import type { ArtId } from '../../design/art';
import { useRouteTheme } from '../../design/display';
import { divisionOfPath, readLastDivision, rememberDivision } from '../../design/last-division';
import { divisionTheme } from '../../design/themes';
import { PageBackdrop } from './PageBackdrop';

const SLOT: Record<DivisionId, ArtId> = {
  salon: 'salonBackground',
  spa: 'spaBackground',
  'beauty-parlor': 'parlorBackground',
};
/** Every page that is not a division page or the home page wears the last-viewed division. */
function LastDivision({ division }: { division: DivisionId }) {
  useRouteTheme(divisionTheme[division]);
  return <PageBackdrop key={division} slot={SLOT[division]} />;
}

/**
 * The one shared page background, rendered by every layout (task: backgrounds on every page).
 * Fixed behind all content, under a readability overlay; the picture comes from the photo-slot
 * helper (a plain themed gradient when there is no photo). Which picture:
 * home -> none (the page paints its own sections); /salon, /spa, /beauty-parlor -> that division's;
 * anything else -> the division the visitor viewed last (kept per browser, default spa).
 * `fixed` overrides all of this (staff portals always use the shop background).
 */
export function PageBackground({ fixed, plain }: { fixed?: ArtId; plain?: boolean }) {
  const { pathname } = useLocation();
  const viewing = divisionOfPath(pathname);
  useEffect(() => {
    if (viewing) rememberDivision(viewing);
  }, [viewing]);
  // The customer area is calm and plain: no photo behind forms, lists and prices.
  if (plain) return null;
  if (fixed) return <PageBackdrop slot={fixed} />;
  // The home page is designed to stand on its own surface: no photo behind the text.
  if (pathname === '/') return null;
  // A division page sets its own theme (DivisionPage); other pages borrow the last division's.
  // Division pages carry their own photo in the hero, so nothing sits behind the text.
  if (viewing) return null;
  return <LastDivision division={readLastDivision()} />;
}
