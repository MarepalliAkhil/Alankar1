import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Service, SiteData } from '../../api/public';
import { divisions, type DivisionId } from '../../config/divisions';
import { ThemeScope } from '../../design/ThemeProvider';
import type { ArtId } from '../../design/art';
import { divisionTheme } from '../../design/themes';
import { formatINR } from '../../lib/format';
import { PageContainer } from '../layout/PageContainer';
import { AlankarIcon, ArtImage, type AlankarIconName } from '../ui';
import { Reveal } from './Reveal';

const PHOTO: Record<DivisionId, ArtId> = {
  salon: 'salonHero',
  spa: 'spaHero',
  'beauty-parlor': 'parlorHero',
};
const ICONS: Record<DivisionId, AlankarIconName[]> = {
  salon: ['scissors', 'comb', 'mirror'],
  spa: ['lotus', 'stones', 'leaf'],
  'beauty-parlor': ['flower', 'brush', 'bangle'],
};
const LINES: Record<DivisionId, { kicker: string; line: string }> = {
  salon: { kicker: '01', line: 'Cuts, colour, beard and grooming. Sharp work, no fuss.' },
  spa: { kicker: '02', line: 'Massage and slow-down time. Phones stay in the locker.' },
  'beauty-parlor': { kicker: '03', line: 'Skin, bridal, nails and waxing. Wedding season ready.' },
};

function Start({ services, id }: { services: readonly Service[]; id: DivisionId }) {
  const first = services.filter((s) => s.division === id)[0];
  return first ? (
    <span className="tabular text-sm">
      {first.name} from {formatINR(first.from_price)}
    </span>
  ) : null;
}

/**
 * Three doors, one per division. Each previews its own look (type, corner shape, ornament, motion)
 * by wearing its theme, so a visitor sees the difference before they click.
 */
export function DivisionDoors({
  site,
  services,
}: {
  site: SiteData | undefined;
  services: readonly Service[];
}) {
  const count = (id: DivisionId) => site?.stats?.divisions?.[id];
  const [salon, spa, parlor] = divisions;
  return (
    <section
      id="divisions"
      data-home-chapter="2"
      aria-labelledby="divisions-title"
      className="scroll-mt-24 py-xl"
    >
      <PageContainer>
        <Reveal>
          <h2
            id="divisions-title"
            className="glass-photo mb-lg inline-block max-w-2xl rounded-card px-lg py-md text-4xl"
          >
            Three places to spend an hour well
          </h2>
        </Reveal>
        <ul className="grid gap-md lg:grid-cols-12 lg:grid-rows-2">
          <li className="lg:col-span-5 lg:row-span-2">
            <Door id={salon.id} label={salon.label} path={salon.path} count={count(salon.id)}>
              <SalonBody services={services} />
            </Door>
          </li>
          <li className="lg:col-span-7">
            <Door id={spa.id} label={spa.label} path={spa.path} count={count(spa.id)}>
              <SpaBody services={services} />
            </Door>
          </li>
          <li className="lg:col-span-7">
            <Door id={parlor.id} label={parlor.label} path={parlor.path} count={count(parlor.id)}>
              <ParlorBody services={services} />
            </Door>
          </li>
        </ul>
      </PageContainer>
    </section>
  );
}

function Icons({ id }: { id: DivisionId }) {
  return (
    <span className="flex gap-sm text-primary-hover" aria-hidden="true">
      {ICONS[id].map((name) => (
        <AlankarIcon key={name} name={name} className="h-6 w-6" />
      ))}
    </span>
  );
}

function Door({
  id,
  label,
  path,
  count,
  children,
}: {
  id: DivisionId;
  label: string;
  path: string;
  count: number | undefined;
  children: React.ReactNode;
}) {
  return (
    <ThemeScope
      theme={divisionTheme[id]}
      mode={id === 'salon' ? 'dark' : undefined}
      className="h-full"
    >
      <Reveal className="h-full">
        <Link
          to={path}
          aria-label={`${label}: ${LINES[id].line}`}
          className="group relative flex h-full min-h-[22rem] flex-col justify-between gap-lg overflow-hidden rounded-card border border-border bg-surface p-lg text-text transition-transform duration-base ease-brand hover:-translate-y-1 focus-visible:shadow-focus focus-visible:outline-none"
        >
          <span aria-hidden="true" className="ornament absolute inset-0" />
          {children}
          <span className="relative z-10 flex items-center justify-between gap-md border-t border-border pt-md text-sm font-semibold text-primary-hover">
            <span className="tabular">{count != null ? `${count} services` : 'See the menu'}</span>
            <span className="inline-flex items-center gap-1">
              Open {label.toLowerCase()}
              <ArrowRight
                aria-hidden="true"
                className="h-4 w-4 transition-transform duration-base ease-brand group-hover:translate-x-1"
              />
            </span>
          </span>
        </Link>
      </Reveal>
    </ThemeScope>
  );
}

function SalonBody({ services }: { services: readonly Service[] }) {
  return (
    <div className="relative z-10 flex flex-1 flex-col gap-md">
      <div className="flex items-start justify-between gap-md">
        <span className="font-display text-2xl text-primary-hover">{LINES.salon.kicker}</span>
        <Icons id="salon" />
      </div>
      <h3 className="text-6xl italic">Salon</h3>
      <p className="max-w-[28ch] text-lg text-text-muted">{LINES.salon.line}</p>
      <div className="relative mt-auto aspect-[3/2] overflow-hidden rounded-card border border-border">
        <ArtImage slot={PHOTO.salon} className="absolute inset-0 h-full w-full" />
      </div>
      <Start services={services} id="salon" />
    </div>
  );
}

function SpaBody({ services }: { services: readonly Service[] }) {
  return (
    <div className="relative z-10 grid flex-1 items-center gap-lg sm:grid-cols-5">
      <div className="flex flex-col gap-md sm:col-span-3">
        <Icons id="spa" />
        <h3 className="text-5xl">Spa</h3>
        <p className="max-w-[34ch] text-lg text-text-muted">{LINES.spa.line}</p>
        <Start services={services} id="spa" />
      </div>
      <div className="shape-arch relative mx-auto aspect-[3/4] w-full max-w-[14rem] overflow-hidden border border-border sm:col-span-2">
        <ArtImage slot={PHOTO.spa} className="absolute inset-0 h-full w-full" />
      </div>
    </div>
  );
}

function ParlorBody({ services }: { services: readonly Service[] }) {
  return (
    <div className="relative z-10 grid flex-1 items-center gap-lg sm:grid-cols-5">
      <div className="shape-leaf relative order-2 mx-auto aspect-square w-full max-w-[14rem] overflow-hidden border border-border sm:order-1 sm:col-span-2">
        <ArtImage slot={PHOTO['beauty-parlor']} className="absolute inset-0 h-full w-full" />
      </div>
      <div className="order-1 flex flex-col gap-md sm:order-2 sm:col-span-3">
        <Icons id="beauty-parlor" />
        <h3 className="text-4xl sm:text-5xl">Beauty Parlor</h3>
        <p className="max-w-[34ch] text-lg text-text-muted">{LINES['beauty-parlor'].line}</p>
        <Start services={services} id="beauty-parlor" />
      </div>
    </div>
  );
}
