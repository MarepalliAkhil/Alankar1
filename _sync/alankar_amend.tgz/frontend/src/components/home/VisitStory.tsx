import type { ReactNode } from 'react';
import type { Service } from '../../api/public';
import { formatINR } from '../../lib/format';
import { cn } from '../../lib/cn';
import { PageContainer } from '../layout/PageContainer';
import { AlankarIcon, type AlankarIconName } from '../ui';
import { Reveal } from './Reveal';

interface Chapter {
  id: string;
  icon: AlankarIconName;
  title: string;
  text: string;
  visual: ReactNode;
}

/** Which of the six home background chapters each story step belongs to (see HomeBackdrop). */
const CHAPTER_OF: Record<string, number> = {
  find: 2,
  book: 3,
  approve: 4,
  visit: 5,
  pay: 6,
  rate: 6,
};

/** A mock of one real screen, labelled as an example, hidden from screen readers (the text says it). */
function Shot({ caption, children }: { caption: string; children: ReactNode }) {
  return (
    <figure className="m-0">
      <div
        aria-hidden="true"
        className="rounded-card border border-border bg-surface p-md shadow-card"
      >
        {children}
      </div>
      <figcaption className="mt-sm text-xs text-text-muted">{caption}</figcaption>
    </figure>
  );
}

const chip = 'rounded-full border border-border px-3 py-1 text-sm';

function MenuShot({ services }: { services: readonly Service[] }) {
  const rows = services.slice(0, 3);
  return (
    <Shot caption="Part of our menu. Prices include GST.">
      <ul className="flex flex-col divide-y divide-border">
        {rows.length === 0 && <li className="py-sm text-sm text-text-muted">Men's Haircut</li>}
        {rows.map((s) => (
          <li key={s.id} className="flex items-baseline justify-between gap-md py-sm">
            <span className="font-medium text-text">{s.name}</span>
            <span className="tabular text-sm text-text-muted">from {formatINR(s.from_price)}</span>
          </li>
        ))}
      </ul>
    </Shot>
  );
}

function TimeShot() {
  return (
    <Shot caption="Choose a day, a time and a stylist, or leave the stylist to us.">
      <p className="text-sm font-semibold text-text">Saturday</p>
      <div className="mt-sm flex flex-wrap gap-sm">
        {['10:30 am', '11:00 am', '12:30 pm', '4:00 pm'].map((t, i) => (
          <span
            key={t}
            className={cn(
              chip,
              'tabular',
              i === 2 ? 'border-primary bg-primary text-on-primary' : 'text-text',
            )}
          >
            {t}
          </span>
        ))}
      </div>
      <p className="mt-md text-sm text-text-muted">Stylist: any available</p>
    </Shot>
  );
}

function ApprovalShot() {
  const row = (who: string, state: string) => (
    <li className="flex items-center justify-between gap-md py-sm">
      <span className="text-text">{who}</span>
      <span className="inline-flex items-center gap-1 rounded-full bg-success-soft px-3 py-1 text-sm font-medium text-success-text">
        <AlankarIcon name="approve" className="h-4 w-4" />
        {state}
      </span>
    </li>
  );
  return (
    <Shot caption="You see both answers on your booking.">
      <ul className="divide-y divide-border">
        {row('Front desk', 'Said yes')}
        {row('Your stylist', 'Said yes')}
      </ul>
      <p className="mt-sm rounded-nested bg-primary-soft px-md py-sm text-sm text-text">
        Both confirmed. Your payment link is ready.
      </p>
    </Shot>
  );
}

function VisitShot() {
  return (
    <Shot caption="Tap I'm here when you arrive. The front desk checks you in.">
      <span className="inline-flex h-10 items-center rounded-full bg-primary px-4 text-sm font-semibold text-on-primary">
        I'm here
      </span>
      <ol className="mt-md flex flex-wrap gap-sm text-sm text-text-muted">
        <li className={chip}>Checked in</li>
        <li className={chip}>In progress</li>
        <li className={chip}>Done</li>
      </ol>
    </Shot>
  );
}

function PayShot() {
  return (
    <Shot caption="Your online payment is counted at the desk. You settle only what is extra.">
      <p className="text-sm text-text-muted">Men's Haircut</p>
      <p className="tabular mt-1 font-display text-4xl text-text">{formatINR(300)}</p>
      <p className="text-xs text-text-muted">including GST</p>
      <p className="mt-md text-sm text-text">
        Pay by card or UPI. Cash and gift cards at the desk.
      </p>
    </Shot>
  );
}

function RateShot() {
  return (
    <Shot caption="A rating takes ten seconds. Stylists see it without your name.">
      <div className="flex gap-1 text-accent">
        {[1, 2, 3, 4, 5].map((n) => (
          <AlankarIcon key={n} name="star" className={cn('h-7 w-7', n === 5 && 'opacity-30')} />
        ))}
      </div>
      <p className="mt-sm text-sm text-text-muted">Calm hands, finished on time.</p>
    </Shot>
  );
}

/**
 * The scroll story: six chapters of a visit, each with a real-looking piece of the app. Layout
 * changes from chapter to chapter (visual left, visual right, full-width band, centred) so the
 * page has rhythm instead of six equal rows.
 */
export function VisitStory({ services }: { services: readonly Service[] }) {
  const chapters: Chapter[] = [
    {
      id: 'find',
      icon: 'search',
      title: 'Find what you need',
      text: 'Browse the salon, the spa and the beauty parlor. Filter by who it is for, and see the price with GST before you decide.',
      visual: <MenuShot services={services} />,
    },
    {
      id: 'book',
      icon: 'calendar',
      title: 'Ask for a time',
      text: 'Choose a day, a time and a stylist. You send a request, not a promise, so nothing is held against your card.',
      visual: <TimeShot />,
    },
    {
      id: 'approve',
      icon: 'approve',
      title: 'Your stylist says yes',
      text: 'The front desk and your stylist each answer your request. When both say yes, you get a payment link by email. If either cannot do it, we tell you politely and help you pick another time.',
      visual: <ApprovalShot />,
    },
    {
      id: 'visit',
      icon: 'door',
      title: 'Walk in',
      text: 'Tap I am here when you arrive. Your stylist starts the service and you can sit back.',
      visual: <VisitShot />,
    },
    {
      id: 'pay',
      icon: 'rupee',
      title: 'Settle up',
      text: 'The payment link locks your slot before you come. At the desk we count it against your bill, and you pay anything extra by cash, card, UPI or gift card.',
      visual: <PayShot />,
    },
    {
      id: 'rate',
      icon: 'star',
      title: 'Tell us how it went',
      text: 'Rate your stylist after the visit. It helps the team, and it keeps your next booking simple.',
      visual: <RateShot />,
    },
  ];
  return (
    <section
      id="how-it-works"
      aria-labelledby="story-title"
      className="relative scroll-mt-24 py-2xl"
    >
      <PageContainer className="relative">
        <Reveal className="glass-photo rounded-card p-lg">
          <p className="text-sm font-semibold uppercase tracking-wide text-primary-hover">
            How a visit works
          </p>
          <h2 id="story-title" className="mt-1 max-w-3xl text-4xl">
            From “I need a haircut” to “thank you”, in six small steps
          </h2>
        </Reveal>
        <ol className="mt-xl flex flex-col">
          {chapters.map((c, i) => {
            const flip = i % 2 === 1;
            const band = c.id === 'approve';
            const centred = c.id === 'rate';
            return (
              <Reveal
                as="li"
                key={c.id}
                data-home-chapter={CHAPTER_OF[c.id]}
                className={cn(
                  'glass-photo mb-lg grid items-center gap-lg rounded-card px-lg',
                  i % 3 === 0 ? 'py-xl' : i % 3 === 1 ? 'py-lg' : 'py-2xl',
                  band && 'lg:grid-cols-12',
                  centred ? 'mx-auto max-w-xl text-center' : !band && 'lg:grid-cols-2 lg:gap-2xl',
                )}
              >
                <div
                  className={cn(
                    'flex flex-col gap-sm',
                    flip && !band && 'lg:order-2',
                    band && 'lg:col-span-5',
                    centred && 'items-center',
                  )}
                >
                  <span className="flex items-center gap-sm text-primary-hover">
                    <span className="tabular font-display text-5xl">{`0${i + 1}`}</span>
                    <AlankarIcon name={c.icon} className="h-8 w-8" />
                  </span>
                  <h3 className="text-3xl">{c.title}</h3>
                  <p className="max-w-[46ch] text-lg text-text-muted">{c.text}</p>
                </div>
                <div className={cn(band && 'lg:col-span-6 lg:col-start-7', centred && 'w-full')}>
                  {c.visual}
                </div>
              </Reveal>
            );
          })}
        </ol>
      </PageContainer>
    </section>
  );
}
