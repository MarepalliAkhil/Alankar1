import { useEffect, useState } from 'react';
import type { Chapter } from '../design/art';

/** The six chapters of the home page background, in order. */
export const HOME_CHAPTERS: readonly Chapter[] = [1, 2, 3, 4, 5, 6];

/**
 * Which chapter is in the middle of the screen. Sections mark themselves with
 * `data-home-chapter="1..6"`; one light IntersectionObserver watches them (no scroll listener, no
 * layout work). Without IntersectionObserver the first chapter stays.
 */
export function useHomeChapter(): Chapter {
  const [chapter, setChapter] = useState<Chapter>(1);
  useEffect(() => {
    if (typeof IntersectionObserver === 'undefined') return;
    const watched = new WeakSet<Element>();
    const seen = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          const value = Number((entry.target as HTMLElement).dataset.homeChapter);
          if (value >= 1 && value <= 6) setChapter(value as Chapter);
        }
      },
      { rootMargin: '-45% 0px -45% 0px' },
    );
    // The sections may be drawn after the page content arrives from the server (slow network or
    // machine), so new ones are picked up as they appear instead of only once at the start.
    const scan = () => {
      document.querySelectorAll('[data-home-chapter]').forEach((el) => {
        if (watched.has(el)) return;
        watched.add(el);
        seen.observe(el);
      });
    };
    scan();
    let frame = 0;
    const added =
      typeof MutationObserver === 'undefined'
        ? null
        : new MutationObserver(() => {
            if (frame) return;
            frame = window.requestAnimationFrame(() => {
              frame = 0;
              scan();
            });
          });
    added?.observe(document.body, { childList: true, subtree: true });
    return () => {
      added?.disconnect();
      if (frame) window.cancelAnimationFrame(frame);
      seen.disconnect();
    };
  }, []);
  return chapter;
}
