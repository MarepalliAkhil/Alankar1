// Task 11: the photo slots, shared by the app (src/design/art.ts), the photo manifest plugin and
// the `npm run photos:check` / `npm run photos:optimize` scripts. Plain JavaScript so Node can
// run it without a build step.

/** Accepted photo formats, in order of preference (the first one found wins). */
export const PHOTO_EXTENSIONS = ['webp', 'jpg', 'jpeg', 'png'];

/** Every photo slot: the base file name in public/photos and the size it is shown at. */
export const PHOTO_SLOTS = {
  'salon-hero': { width: 1920, height: 1080 },
  'spa-hero': { width: 1920, height: 1080 },
  'parlor-hero': { width: 1920, height: 1080 },
  'shop-background': { width: 1920, height: 1080 },
  'salon-background': { width: 1600, height: 1000 },
  'spa-background': { width: 1600, height: 1000 },
  'parlor-background': { width: 1600, height: 1000 },
};

// Task 17C: the home page's scrolling background. Six chapters for the neutral brand look
// (hero-scroll-01..06) and for each division look (salon-/spa-/parlor-hero-scroll-01..06).
export const HERO_LOOKS = ['neutral', 'salon', 'spa', 'parlor'];
export const HERO_CHAPTERS = [1, 2, 3, 4, 5, 6];
export const heroScrollSlot = (look, chapter) =>
  `${look === 'neutral' ? '' : `${look}-`}hero-scroll-0${chapter}`;
for (const look of HERO_LOOKS) {
  for (const chapter of HERO_CHAPTERS) {
    PHOTO_SLOTS[heroScrollSlot(look, chapter)] = { width: 1920, height: 1080 };
  }
}

// Task 17D: the Alankar brand image (profile page) and one header image per page. Customer and
// public pages show a 4:1 banner; staff pages a slim strip cropped from a 8:1 image.
PHOTO_SLOTS['brand-image'] = { width: 1920, height: 1080 };
export const CUSTOMER_PAGE_SLOTS = [
  'book-hero',
  'bookings-hero',
  'chat-hero',
  'wallet-hero',
  'packages-hero',
  'shop-hero',
  'orders-hero',
  'customer-dashboard-hero',
  'zenotians-hero',
  'login-hero',
  'register-hero',
];
export const STAFF_PAGE_SLOTS = [
  'giftcards-hero',
  'stylist-requests-hero',
  'stylist-schedule-hero',
  'receptionist-board-hero',
  'admin-stats-hero',
  'payroll-hero',
  'inventory-hero',
];
for (const slot of CUSTOMER_PAGE_SLOTS) PHOTO_SLOTS[slot] = { width: 1600, height: 400 };
for (const slot of STAFF_PAGE_SLOTS) PHOTO_SLOTS[slot] = { width: 1920, height: 240 };

// Task 17 amendment: Meera, the tour guide, is a set of pictures the owner supplies (3D-style
// renders). Put `meera-<pose>.png|webp|jpg|jpeg` in public/photos/meera/ (or public/photos/).
export const MEERA_POSES = [
  'wave',
  'point',
  'phone',
  'approve',
  'chat',
  'wallet',
  'stars',
  'shield',
  'celebrate',
];
/** The folder (inside public/photos) where Meera's pictures live. */
export const MEERA_FOLDER = 'meera';
for (const pose of MEERA_POSES) PHOTO_SLOTS[`meera-${pose}`] = { width: 1024, height: 1280 };
/** Slots whose pictures can be cut-outs with transparency: kept as WebP + PNG, never flattened to JPG. */
export const isTransparentSlot = (slot) => slot.startsWith('meera-');

// Task 17 amendment: the owner's own photos only, no drawings. Seven photos exist (the base
// slots above). Every other picture slot is ASSIGNED one of them with its own crop, so
// neighbouring chapters and pages look different until a photo of its own is added:
//   from      the base slot whose photo is used
//   position  CSS object-position ("x% y%": which part of the photo stays in view)
//   zoom      1 = the whole photo; 1.5 = a close crop (scaled from `position`)
// A slot's own photo (public/photos/<slot>.*) always wins over its assignment. A slot whose
// assigned photo is also missing shows a plain themed gradient. Used by the app (ArtImage), by
// `npm run photos:inventory` (docs/IMAGE_INVENTORY.md) and by the unit tests.
const crop = (from, position, zoom = 1) => ({ from, position, zoom });
export const PHOTO_PLAN = {
  // Home, neutral look (visitors on the main home page).
  'hero-scroll-01': crop('shop-background', '50% 50%'),
  'hero-scroll-02': crop('salon-hero', '60% 55%', 1.1),
  'hero-scroll-03': crop('parlor-background', '55% 45%', 1.1),
  'hero-scroll-04': crop('spa-background', '60% 60%', 1.1),
  'hero-scroll-05': crop('shop-background', '80% 55%', 1.7),
  'hero-scroll-06': crop('shop-background', '22% 62%', 1.7),
  // Home, Salon look.
  'salon-hero-scroll-01': crop('salon-hero', '50% 50%'),
  'salon-hero-scroll-02': crop('salon-background', '55% 55%', 1.05),
  'salon-hero-scroll-03': crop('salon-hero', '88% 40%', 1.8),
  'salon-hero-scroll-04': crop('salon-background', '78% 72%', 1.8),
  'salon-hero-scroll-05': crop('salon-hero', '18% 55%', 1.5),
  'salon-hero-scroll-06': crop('salon-background', '14% 45%', 1.5),
  // Home, Spa look.
  'spa-hero-scroll-01': crop('spa-hero', '50% 50%'),
  'spa-hero-scroll-02': crop('spa-background', '55% 55%', 1.05),
  'spa-hero-scroll-03': crop('spa-hero', '70% 78%', 1.7),
  'spa-hero-scroll-04': crop('spa-background', '82% 78%', 1.8),
  'spa-hero-scroll-05': crop('spa-hero', '12% 40%', 1.5),
  'spa-hero-scroll-06': crop('spa-background', '10% 40%', 1.5),
  // Home, Beauty Parlor look.
  'parlor-hero-scroll-01': crop('parlor-hero', '50% 50%'),
  'parlor-hero-scroll-02': crop('parlor-background', '55% 55%', 1.05),
  'parlor-hero-scroll-03': crop('parlor-hero', '76% 35%', 1.8),
  'parlor-hero-scroll-04': crop('parlor-background', '80% 55%', 1.7),
  'parlor-hero-scroll-05': crop('parlor-hero', '82% 68%', 1.8),
  'parlor-hero-scroll-06': crop('parlor-background', '15% 15%', 1.6),
  // The Alankar brand image (profile pages): the reception with the Alankar sign.
  'brand-image': crop('shop-background', '50% 50%'),
  // Customer pages (4:1 banners).
  'book-hero': crop('shop-background', '20% 55%', 1.5),
  'bookings-hero': crop('shop-background', '78% 55%', 1.5),
  'chat-hero': crop('salon-background', '60% 55%', 1.3),
  'wallet-hero': crop('parlor-background', '70% 40%', 1.2),
  'packages-hero': crop('spa-hero', '70% 72%', 1.3),
  'shop-hero': crop('shop-background', '38% 78%', 1.8),
  'orders-hero': crop('shop-background', '66% 62%', 1.7),
  'customer-dashboard-hero': crop('shop-background', '50% 45%', 1.15),
  'zenotians-hero': crop('salon-hero', '50% 42%', 1.1),
  'login-hero': crop('parlor-hero', '75% 35%', 1.3),
  'register-hero': crop('spa-hero', '60% 55%', 1.2),
  // Staff pages (slim strips).
  'giftcards-hero': crop('parlor-background', '60% 45%', 1.3),
  'stylist-requests-hero': crop('salon-hero', '62% 58%', 1.3),
  'stylist-schedule-hero': crop('salon-background', '50% 60%', 1.2),
  'receptionist-board-hero': crop('shop-background', '25% 55%', 1.4),
  'admin-stats-hero': crop('shop-background', '50% 50%', 1.2),
  'payroll-hero': crop('salon-hero', '25% 50%', 1.4),
  'inventory-hero': crop('parlor-hero', '72% 80%', 1.4),
};

// What each slot should show: shown in docs/IMAGE_SLOTS.md ("STILL NEEDED") and the unit tests.
const LOOK_SHOW = {
  neutral: 'the Alankar brand look (aubergine and amber)',
  salon: 'the Salon look (navy, gold and copper)',
  spa: 'the Spa look (sage, sand and clay)',
  parlor: 'the Beauty Parlor look (blush, rose and gold)',
};
const CHAPTER_SHOW = {
  1: 'a wide, welcoming view of the shop itself (the Alankar brand moment)',
  2: 'finding a service: shelves of products, a counter of tools, a menu board',
  3: 'booking: a stylist or receptionist with a diary or screen, calm and unhurried',
  4: 'approval: two team members at the desk, one nodding, quiet energy',
  5: 'your visit: a client in the chair at the mirror, tools laid out',
  6: 'paying and rating: the front desk, a card machine and a happy client leaving',
};
export const SLOT_SHOWS = {};
for (const look of HERO_LOOKS) {
  for (const chapter of HERO_CHAPTERS) {
    SLOT_SHOWS[heroScrollSlot(look, chapter)] =
      `Home background chapter ${chapter}, ${LOOK_SHOW[look]}: ${CHAPTER_SHOW[chapter]}.`;
  }
}
Object.assign(SLOT_SHOWS, {
  'brand-image':
    'The Alankar brand image (profile pages and home chapter 1): the shop with its sign, wide and bright.',
  'book-hero': 'Book page header: a booking desk or appointment book, wide, calm.',
  'bookings-hero':
    'My bookings header: a tidy appointment schedule or a stylist checking the diary.',
  'chat-hero': 'Zen Chat header: a stylist and a client chatting at a station, friendly.',
  'wallet-hero': 'Gift cards and wallet header: gift boxes and cards on a marble counter.',
  'packages-hero': 'Packages and memberships header: a spa tray with towels and a candle.',
  'shop-hero': 'Shop header: shelves of hair, skin and spa products, well lit.',
  'orders-hero': 'Orders header: a wrapped parcel, bag or products on a counter.',
  'customer-dashboard-hero': 'Customer dashboard header: the lounge or reception, welcoming.',
  'zenotians-hero': 'For Zenotians header: the team at work, or a clean studio, wide.',
  'login-hero': 'Login header: the shop entrance or a door with warm light.',
  'register-hero': 'Register header: a welcoming reception desk.',
  'giftcards-hero': 'Admin gift cards header strip: ribbon and gift boxes, very wide.',
  'stylist-requests-hero':
    'Stylist requests header strip: a stylist station with tools, very wide.',
  'stylist-schedule-hero': 'Stylist schedule header strip: a wall clock or a diary, very wide.',
  'receptionist-board-hero':
    'Receptionist board header strip: the front desk seen from the side, very wide.',
  'admin-stats-hero': 'Admin statistics header strip: a tidy office desk with a screen, very wide.',
  'payroll-hero': 'Payroll header strip: a ledger and a calculator on a desk, very wide.',
  'inventory-hero': 'Inventory header strip: stocked shelves of products, very wide.',
});
const MEERA_SHOWS = {
  wave: 'Meera, the stylist guide, waving hello (welcome).',
  point: 'Meera pointing to the side at something (pick a service, the menu).',
  phone: 'Meera holding a phone showing a booking (the booking step).',
  approve: 'Meera giving a thumbs-up (the request was approved).',
  chat: 'Meera with a chat bubble or a phone, chatting (Zen Chat).',
  wallet: 'Meera holding a wallet or a gift card (pay and save).',
  stars: 'Meera holding five stars or a rating card (rate your visit).',
  shield: 'Meera with a shield or a padlock (stay safe: trusted devices and privacy).',
  celebrate: 'Meera celebrating with her arms up and confetti (the finale).',
};
for (const pose of MEERA_POSES) SLOT_SHOWS[`meera-${pose}`] = MEERA_SHOWS[pose];

/** The slots that have their own photo file (not just an assignment): everything else is "needed". */
/** Photos above this size slow the page down; photos:check warns about them. */
export const MAX_PHOTO_BYTES = 200 * 1024;

/**
 * The file to use for a slot from a list of file names: `<base>.webp`, then `.jpg`, `.jpeg`,
 * `.png` (any letter case). Returns null when none exists (a plain themed gradient is shown).
 */
export function pickPhoto(base, files) {
  // A file in a sub-folder ("meera/meera-wave.png") counts under its own name; a file straight in
  // public/photos wins over one in a sub-folder.
  const lower = new Map();
  for (const name of files) {
    const key = name.slice(name.lastIndexOf('/') + 1).toLowerCase();
    if (!lower.has(key) || !name.includes('/')) lower.set(key, name);
  }
  for (const ext of PHOTO_EXTENSIONS) {
    const found = lower.get(`${base}.${ext}`.toLowerCase());
    if (found) return found;
  }
  return null;
}
