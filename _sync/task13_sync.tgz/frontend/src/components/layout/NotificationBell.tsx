import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Bell } from 'lucide-react';
import { useEffect, useId, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  listNotifications,
  markNotificationsRead,
  type AppNotification,
} from '../../api/notifications';
import { formatDateTime } from '../../lib/format';
import { cn } from '../../lib/cn';
import { IconButton } from '../ui/IconButton';

/** In-app notifications for the signed-in person: a bell with an unread count and a short list. */
export function NotificationBell({ className }: { className?: string }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const panelId = useId();
  const queryClient = useQueryClient();
  const list = useQuery({
    queryKey: ['notifications'],
    queryFn: listNotifications,
    refetchInterval: 60_000,
  });
  const markRead = useMutation({
    mutationFn: () => markNotificationsRead(),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['notifications'] }),
  });

  useEffect(() => {
    if (!open) return;
    const onPointer = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onPointer);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onPointer);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const unread = list.data?.unread ?? 0;
  const items = list.data?.results ?? [];
  return (
    <div ref={rootRef} className={cn('relative', className)}>
      <div className="relative">
        <IconButton
          label={unread > 0 ? `Notifications, ${unread} unread` : 'Notifications'}
          aria-expanded={open}
          aria-controls={open ? panelId : undefined}
          icon={<Bell className="h-5 w-5" />}
          onClick={() => setOpen((value) => !value)}
        />
        {unread > 0 && (
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary-hover px-1 text-xs font-semibold text-white"
          >
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </div>
      {open && (
        <section
          id={panelId}
          aria-label="Notifications"
          className="absolute right-0 z-overlay mt-sm w-80 max-w-[calc(100vw-2rem)] rounded-card bg-surface p-sm shadow-raised"
        >
          <div className="flex items-center justify-between px-sm py-1">
            <h2 className="text-sm font-semibold text-text">Notifications</h2>
            {unread > 0 && (
              <button
                type="button"
                className="rounded text-xs font-medium text-primary-hover focus-visible:shadow-focus focus-visible:outline-none"
                onClick={() => markRead.mutate()}
              >
                Mark all as read
              </button>
            )}
          </div>
          {list.isError ? (
            <p className="px-sm py-md text-sm text-text-muted">We couldn&apos;t load these.</p>
          ) : items.length === 0 ? (
            <p className="px-sm py-md text-sm text-text-muted">Nothing new.</p>
          ) : (
            <ul className="flex max-h-96 flex-col gap-1 overflow-y-auto">
              {items.map((item) => (
                <li key={item.id}>
                  <Item item={item} onNavigate={() => setOpen(false)} />
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
    </div>
  );
}

function Item({ item, onNavigate }: { item: AppNotification; onNavigate: () => void }) {
  const body = (
    <>
      <span className={cn('block text-sm text-text', !item.read_at && 'font-semibold')}>
        {item.title}
      </span>
      {item.body && <span className="block text-xs text-text-muted">{item.body}</span>}
      <span className="block text-xs text-text-muted">{formatDateTime(item.created_at)}</span>
    </>
  );
  const cls =
    'block rounded-nested px-sm py-sm hover:bg-primary-soft focus-visible:bg-primary-soft focus-visible:outline-none';
  return item.link.startsWith('/') ? (
    <Link to={item.link} className={cls} onClick={onNavigate}>
      {body}
    </Link>
  ) : (
    <div className={cls}>{body}</div>
  );
}
